"""hiii mibam

Rough color map:
    RED: errors or something important
    BLUE: scp stuff
    GOLD: gold bars
    GREEN: successes
    MAGENTA: trivia

Settings:
    Grind SCP: sends Glory to the CCP! to grind scp
    Grind Trivia: answers trivia questions to grind scp
    Snipe Gold: attempts to snipe gold bars from the shop
    Coinflip: gamble scp if you get it from grind scp. Formula: scp gained % 100 (aka 120 gained % 100 = 20 scp bet)
    Auto-Stop: stops grind scp if mod/tester is in grinding channel. Starts after 60s of no activity
"""

import os
import re
import html
import time
import json
import random
import atexit
import asyncio
import logging
import argparse
import threading
import websocket
from collections import deque
from difflib import get_close_matches
from dotenv import load_dotenv
from discordws import DiscordWS

try:
    import curses
    HAS_CURSES = True
except ImportError:
    HAS_CURSES = False

try:
    import aiohttp
    import discord
    from discord import app_commands
    from discord.ext import commands
    HAS_DISCORD = True
except ImportError:
    HAS_DISCORD = False


# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

HOLGER_ID      = "1050445714825695242"
GRIND_ID       = "1236718074959364171"
BOT_C_ID       = "1346671299262546013"
GUILD_ID       = "820093197933740062"

SHOP_COMMAND_ID      = "1509679847029473310"
SHOP_COMMAND_VERSION = "1509679847029473311"
SCP_COMMAND_ID       = "1509679839454433330"
SCP_COMMAND_VERSION  = "1509679839454433331"

GRIND_MESSAGE  = "Glory to the CCP!"
SLOWMODE_DELAY = 5.1

STAFF_ROLES = {
    "1238430173297115197": "DSTAFF",
    "820249824757678080":  "STAFF",
    "822919439619850311":  "TESTER",
}
AUTO_STOP_DELAY = 60.0
TRIVIA_RETRY_TIMEOUT = 10.0

LOG_PATH = os.path.join(os.path.dirname(__file__), "logs.jsonl")


def append_log_line(message: str, color: str):
    entry = {"ts": time.time(), "message": message, "color": color}
    try:
        with open(LOG_PATH, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry) + "\n")
    except Exception as e:
        print(f"Failed to write log file: {e}")


def read_log_lines(page: int, amount: int) -> tuple[list[dict], int]:
    """Read logs most-recent-first, paginated. Returns (entries, total_count)."""
    try:
        with open(LOG_PATH, encoding="utf-8") as f:
            lines = f.readlines()
    except FileNotFoundError:
        return [], 0

    total = len(lines)
    lines.reverse()

    start = max(0, (page - 1) * amount)
    end   = start + amount
    page_lines = lines[start:end]

    entries = []
    for line in page_lines:
        line = line.strip()
        if not line:
            continue
        try:
            entries.append(json.loads(line))
        except json.JSONDecodeError:
            continue

    return entries, total


def clear_log_file():
    try:
        open(LOG_PATH, "w").close()
    except Exception as e:
        print(f"Failed to clear log file: {e}")


# ---------------------------------------------------------------------------
# Stats — global (lifetime) + session (this run)
# ---------------------------------------------------------------------------

class Stats:
    KEYS = [
        "count", "credits", "scp", "buttons",
        "trivia", "trivia_answered", "trivia_scp",
        "gold_bars", "sniped_gold",
        "coinflips", "coinflips_won", "coinflips_scp",
    ]

    def __init__(self):
        for k in self.KEYS:
            setattr(self, k, 0)

    def merge(self, other: "Stats"):
        for k in self.KEYS:
            setattr(self, k, getattr(self, k) + getattr(other, k))

    def to_dict(self) -> dict:
        return {k: getattr(self, k) for k in self.KEYS}

    def from_dict(self, data: dict):
        for k in self.KEYS:
            setattr(self, k, data.get(k, 0))


lifetime = Stats()
session  = Stats()


def load_stats():
    try:
        if os.path.exists("stats.json"):
            with open("stats.json") as f:
                lifetime.from_dict(json.load(f))
    except Exception as e:
        print(f"Failed to load stats: {e}")


def save_stats():
    combined = Stats()
    combined.merge(lifetime)
    combined.merge(session)
    try:
        with open("stats.json", "w") as f:
            json.dump(combined.to_dict(), f, indent=4)
    except Exception as e:
        print(f"Failed to save stats: {e}")


# ---------------------------------------------------------------------------
# Settings
# ---------------------------------------------------------------------------

class Settings:
    def __init__(self):
        self.grind_scp    = True
        self.grind_trivia = True
        self.snipe        = True
        self.gamble       = False
        self.auto_stop    = True
        self.paused       = False
        self._pre_pause_grind_scp    = True
        self._pre_pause_grind_trivia = True

    def to_dict(self) -> dict:
        return {
            "grind_scp":    self.grind_scp,
            "grind_trivia": self.grind_trivia,
            "snipe":        self.snipe,
            "gamble":       self.gamble,
            "auto_stop":    self.auto_stop,
        }

    def from_dict(self, data: dict):
        self.grind_scp    = data.get("grind_scp",    True)
        self.grind_trivia = data.get("grind_trivia", True)
        self.snipe        = data.get("snipe",        True)
        self.gamble       = data.get("gamble",       False)
        self.auto_stop    = data.get("auto_stop",    True)


settings = Settings()


def load_settings():
    try:
        if os.path.exists("settings.json"):
            with open("settings.json") as f:
                settings.from_dict(json.load(f))
    except Exception as e:
        print(f"Failed to load settings: {e}")


def save_settings():
    try:
        with open("settings.json", "w") as f:
            json.dump(settings.to_dict(), f, indent=4)
    except Exception as e:
        print(f"Failed to save settings: {e}")


def load_all():
    load_stats()
    load_settings()


def save_all():
    save_stats()
    save_settings()


# ---------------------------------------------------------------------------
# Trivia bank
# ---------------------------------------------------------------------------

TRIVIA_PATH = os.path.join(os.path.dirname(__file__), "trivia.json")


def load_trivia_bank() -> list[dict]:
    try:
        with open(TRIVIA_PATH) as f:
            data = json.load(f)
            return data if isinstance(data, list) else []
    except Exception as e:
        print(f"Failed to load trivia bank: {e}")
        return []


def save_trivia_bank(bank: list[dict]):
    try:
        with open(TRIVIA_PATH, "w") as f:
            json.dump(bank, f, indent=4)
    except Exception as e:
        print(f"Failed to save trivia bank: {e}")


TRIVIA_BANK: list[dict] = load_trivia_bank()


def normalize(text: str) -> str:
    return re.sub(r"\s+", " ", html.unescape(text or "")).strip().lower()


def upsert_trivia(question: str, answer: str):
    norm_q = normalize(question)
    for entry in TRIVIA_BANK:
        if normalize(entry.get("question", "")) == norm_q:
            entry["question"]       = html.unescape(question).strip()
            entry["correct_answer"] = normalize(answer)
            save_trivia_bank(TRIVIA_BANK)
            return
    TRIVIA_BANK.append({
        "question":       html.unescape(question).strip(),
        "correct_answer": normalize(answer),
    })
    save_trivia_bank(TRIVIA_BANK)


def find_trivia(question: str) -> dict | None:
    norm_q  = normalize(question)
    bank_qs = [normalize(e.get("question", "")) for e in TRIVIA_BANK]
    matches = get_close_matches(norm_q, bank_qs, n=1, cutoff=0.7)
    if not matches:
        return None
    return TRIVIA_BANK[bank_qs.index(matches[0])]


# ---------------------------------------------------------------------------
# Client
# ---------------------------------------------------------------------------

class Client(DiscordWS):
    def __init__(self, token: str):
        super().__init__(token)

        self.user_id   = None
        self.user_name = None

        self.queue_logs = deque(maxlen=10)
        self.event_logs = deque(maxlen=20)

        self._start_time        = time.time()
        self.waiting_for_holger = False
        self.pending_button     = False
        self.checking_gold      = False
        self.staff_present      = False
        self.last_send_time     = 0.0
        self.snipe_amount       = 0
        self.gamble_amount      = 0
        self.coinflip_pending   = False
        self.trivia_state       = None

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def jitter(self, base: float, spread: float = 1.0) -> float:
        return base + random.uniform(-spread, spread)

    def queue(self, event: str, delay: float, kwargs: dict = {}):
        self.queue_logs.append((event, time.time() + delay, kwargs))

    def log(self, message: str, color: str = "WHITE"):
        self.event_logs.append((message, color))
        append_log_line(message, color)

    def shift_event(self, event: str, delta: float):
        updated = deque(maxlen=self.queue_logs.maxlen)
        for name, fire_at, kwargs in self.queue_logs:
            if name == event:
                updated.append((name, fire_at + delta, kwargs))
            else:
                updated.append((name, fire_at, kwargs))
        self.queue_logs = updated

    def get_staff_role(self, member: dict) -> str | None:
        roles = member.get("roles", [])
        for role_id, role_name in STAFF_ROLES.items():
            if role_id in roles:
                return role_name
        return None

    def handle_staff_activity(self, member: dict, username: str):
        role = self.get_staff_role(member)
        if not role:
            return
        self.log(f"[self] {username} ({role}) in chat.", "RED")
        if settings.auto_stop:
            self.staff_present = True
            updated = deque(maxlen=self.queue_logs.maxlen)
            found = False
            for name, fire_at, kwargs in self.queue_logs:
                if name == "STAFF_CLEAR":
                    updated.append((name, time.time() + AUTO_STOP_DELAY, kwargs))
                    found = True
                else:
                    updated.append((name, fire_at, kwargs))
            self.queue_logs = updated
            if not found:
                self.queue("STAFF_CLEAR", AUTO_STOP_DELAY)

    # ------------------------------------------------------------------
    # Trivia
    # ------------------------------------------------------------------

    def find_trivia_entry(self, question: str) -> dict | None:
        norm_q  = normalize(html.unescape(question))
        bank_qs = [normalize(e.get("question", "")) for e in TRIVIA_BANK]
        matches = get_close_matches(norm_q, bank_qs, n=1, cutoff=0.7)
        if not matches:
            return None
        return TRIVIA_BANK[bank_qs.index(matches[0])]

    def start_trivia(self, msg: dict, embed: dict):
        session.trivia += 1
        question = embed.get("description", "")
        answers  = [
            normalize(f.get("value", ""))
            for f in embed.get("fields", [])
            if f.get("name", "").startswith("Option")
        ]

        if not answers:
            self.log("[self] Trivia embed had no answer options.", "MAGENTA")
            return

        entry        = self.find_trivia_entry(question)
        known_answer = normalize(entry.get("correct_answer", "")) if entry else None
        if known_answer and known_answer not in answers:
            known_answer = None

        self.trivia_state = {
            "question":            html.unescape(question).strip(),
            "normalized_question": normalize(question),
            "channel_id":          msg.get("channel_id"),
            "message_id":          msg.get("id"),
            "guild_id":            msg.get("guild_id"),
            "answers":             answers,
            "candidates":          list(answers),
            "known_answer":        known_answer,
            "last_sent_answer":    None,
            "last_sent_at":        None,
        }

        self.log(f"[self] Trivia: {self.trivia_state['question']}", "MAGENTA")
        self.queue("TRIVIA_REPLY", self.jitter(4), {
            "channel_id": msg.get("channel_id"),
            "message_id": msg.get("id"),
        })

    def eliminate_trivia_candidate(self, content: str):
        if not self.trivia_state:
            return
        norm = normalize(content)
        candidates = self.trivia_state["candidates"]
        if norm not in candidates:
            return

        self.trivia_state["candidates"] = [c for c in candidates if c != norm]
        remaining = self.trivia_state["candidates"]
        self.log(f"[self] Trivia: eliminated '{norm}' ({len(remaining)} left)", "MAGENTA")

        if not remaining:
            self.log("[self] Trivia: no candidates left, giving up.", "RED")
            self.trivia_state = None
            return

        if len(remaining) < len(candidates):
            already_queued = any(e == "TRIVIA_REPLY" for e, _, _ in self.queue_logs)
            if not already_queued:
                self.log("[self] Trivia: re-queueing with updated candidates.", "MAGENTA")
                self.queue("TRIVIA_REPLY", self.jitter(2), {
                    "channel_id": self.trivia_state["channel_id"],
                    "message_id": self.trivia_state["message_id"],
                })

    def check_trivia_retry_timeout(self, now: float):
        """If our last sent answer hasn't resolved the trivia within
        TRIVIA_RETRY_TIMEOUT seconds, assume it was wrong, eliminate it,
        and queue another attempt with the next candidate. If that empties
        the candidate list, give up on the trivia entirely (it may be
        glitched / unanswerable) and resume grinding."""
        state = self.trivia_state
        if not state or not state.get("last_sent_answer"):
            return
        if any(e == "TRIVIA_REPLY" for e, _, _ in self.queue_logs):
            return
        if (now - state["last_sent_at"]) < TRIVIA_RETRY_TIMEOUT:
            return

        last = state["last_sent_answer"]
        if last in state["candidates"]:
            state["candidates"] = [c for c in state["candidates"] if c != last]
            self.log(f"[self] Trivia: no result after {TRIVIA_RETRY_TIMEOUT:.0f}s, "
                      f"assuming '{last}' was wrong.", "MAGENTA")

        if not state["candidates"]:
            self.log("[self] Trivia: no candidates left, giving up.", "RED")
            self.trivia_state = None
            return

        state["last_sent_answer"] = None
        state["last_sent_at"]     = None
        self.queue("TRIVIA_REPLY", self.jitter(1), {
            "channel_id": state["channel_id"],
            "message_id": state["message_id"],
        })

    def resolve_trivia_answer(self) -> str | None:
        if not self.trivia_state:
            return None
        known      = self.trivia_state.get("known_answer")
        candidates = self.trivia_state.get("candidates", [])
        if known and known in candidates:
            return known
        if candidates:
            if len(candidates) == 1:
                return candidates[0]
            return random.choice(candidates)
        return None

    def handle_trivia_result(self, embed: dict):
        title       = embed.get("title", "")
        description = embed.get("description", "")

        if title == "Trivia Question Answered":
            question = self.trivia_state.get("question", description) if self.trivia_state else description
            answer, reward, winner = None, 0, None

            for field in embed.get("fields", []):
                name  = normalize(field.get("name", ""))
                value = normalize(field.get("value", ""))
                if name == "reward":
                    m = re.search(r"(\d+)", value)
                    if m:
                        reward = int(m.group(1))
                elif name == "answer":
                    answer = value
                elif name == "winner":
                    winner = html.unescape(field.get("value", "")).strip()

            if answer:
                upsert_trivia(question, answer)
                session.trivia_answered += 1
                session.trivia_scp      += reward
                self.log(f"[self] Trivia answered: {answer} (+{reward} SCP)", "GREEN")
                if winner:
                    self.log(f"[self] Winner: {winner}", "GREEN")

            self.trivia_state = None

        elif title == "Error" and "No one answered the trivia question in time" in description:
            m = re.search(r"answer was\s*(.+?)\.?$", description, re.IGNORECASE)
            if m:
                answer   = normalize(m.group(1))
                question = self.trivia_state.get("question", description) if self.trivia_state else description
                upsert_trivia(question, answer)
                self.log(f"[self] Trivia timed out. Answer was: {answer}", "RED")
            self.trivia_state = None

    # ------------------------------------------------------------------
    # Gateway listener
    # ------------------------------------------------------------------

    def listen(self):
        while self.is_connected:
            try:
                raw = self.ws.recv()
                if not raw:
                    continue

                data = json.loads(raw)
                if data.get("s") is not None:
                    self.seq = data["s"]

                op         = data.get("op")
                event_type = data.get("t")

                if op != 0:
                    continue

                if event_type == "READY":
                    self._on_ready(data["d"])
                elif event_type == "MESSAGE_CREATE":
                    self._on_message(data["d"])
                elif event_type == "TYPING_START":
                    self._on_typing(data["d"])

            except websocket.WebSocketConnectionClosedException:
                self.is_connected = False
                self.start(run_forever=False)
            except Exception:
                self.is_connected = False

    def _on_ready(self, d: dict):
        self.session_id = d["session_id"]
        self.user_id    = d["user"]["id"]
        self.user_name  = d["user"]["username"]
        self.log(f"[self] Connected as {self.user_name} ({self.user_id})")
        self.log(f"[self] Session: {self.session_id}")
        self.queue("NEXT_GLORY", 5)
        if settings.snipe:
            self.queue("CHECK_SNIPE", self.jitter(6))

    def _on_message(self, msg: dict):
        channel_id = msg.get("channel_id")
        if channel_id == GRIND_ID:
            self._handle_grind_message(msg)
        elif channel_id == BOT_C_ID:
            self._handle_bot_message(msg)

    def _on_typing(self, d: dict):
        if d.get("channel_id") != GRIND_ID:
            return
        user_id = d.get("user_id")
        if user_id == self.user_id:
            return
        member   = d.get("member", {})
        username = member.get("user", {}).get("username", user_id)
        self.handle_staff_activity(member, username)

    def _handle_grind_message(self, msg: dict):
        author_id   = msg.get("author", {}).get("id")
        content     = msg.get("content", "")
        is_holger   = author_id == HOLGER_ID
        mentions_me = content.startswith(f"<@{self.user_id}>")

        if author_id != self.user_id and not is_holger:
            member   = msg.get("member", {})
            username = msg.get("author", {}).get("username", author_id)
            self.handle_staff_activity(member, username)

        if is_holger and mentions_me:
            self._handle_holger_response(msg, content)

        if self.trivia_state and not is_holger:
            replied_to = msg.get("referenced_message", {}) or {}
            if replied_to.get("id") == self.trivia_state.get("message_id"):
                self.eliminate_trivia_candidate(content)

        for row in msg.get("components", []):
            for component in row.get("components", []):
                if component.get("type") == 2 and mentions_me:
                    custom_id = component.get("custom_id")
                    self.log(f"[self] Button detected: {custom_id}")
                    self.pending_button = True
                    self.queue("CLICK_BUTTON", self.jitter(1), {
                        "application_id": HOLGER_ID,
                        "custom_id":      custom_id,
                        "guild_id":       msg.get("guild_id"),
                        "channel_id":     msg.get("channel_id"),
                        "message_id":     msg.get("id"),
                    })

        for embed in msg.get("embeds", []):
            title = embed.get("title", "")
            if title == "Trivia Question" and settings.grind_trivia:
                self.start_trivia(msg, embed)
            elif title in {"Trivia Question Answered", "Error"} and self.trivia_state:
                self.handle_trivia_result(embed)

    def _handle_holger_response(self, msg: dict, content: str):
        scp_match = re.search(r"\+(\d+) Social Credits have", content)

        if scp_match:
            amount = int(scp_match.group(1))
            session.scp     += amount
            session.credits += 1
            self.log(f"[self] Received {amount} SCP from Holger.", "BLUE")
            self.shift_event("NEXT_GLORY", -15)
            if settings.gamble:
                self.queue("COINFLIP", self.jitter(1), {"scp": amount % 100})

        elif "You have been awarded a" in content:
            session.gold_bars += 1
            self.log("[self] Received a gold bar from Holger.", "YELLOW")
            self.shift_event("NEXT_GLORY", -15)

        else:
            self.log("[self] Holger response received.")

        session.count          += 1
        self.waiting_for_holger = False

        if settings.grind_scp:
            self.queue("NEXT_GLORY", self.jitter(22))

    def _handle_bot_message(self, msg: dict):
        content = msg.get("content", "")

        gold_match = re.search(r"has ([\d,]+) Gold Bars?", content)
        if gold_match and self.checking_gold and settings.snipe:
            amount = int(gold_match.group(1).replace(",", ""))
            if amount > 0:
                self.log(f"[self] Shop has {amount} gold bars.", "YELLOW")
                self.queue("SNIPE", self.jitter(1), {"gold_amount": amount})
            else:
                self.log("[self] Shop is empty.", "YELLOW")
                self.queue("CHECK_SNIPE", self.jitter(60))
            self.checking_gold = False

        flip_match = re.search(r"The coin landed on (heads|tails)", content)
        if flip_match and self.coinflip_pending:
            self._handle_coinflip_result(flip_match.group(1))
        elif "I dropped the coin" in content and self.coinflip_pending:
            self._handle_coinflip_edge()

        for embed in msg.get("embeds", []):
            self._handle_bot_embed(embed)

    def _handle_coinflip_result(self, result: str):
        session.coinflips += 1
        amt = self.gamble_amount
        if result == "heads":
            session.coinflips_won += 1
            session.coinflips_scp += amt * 2
            self.log(f"[self] Coinflip: heads. Won {amt * 2} SCP.", "BLUE")
        else:
            session.coinflips_scp -= amt
            self.log(f"[self] Coinflip: tails. Lost {amt} SCP.", "RED")
        self.coinflip_pending = False

    def _handle_coinflip_edge(self):
        session.coinflips     += 1
        session.coinflips_scp -= self.gamble_amount / 2
        self.log(f"[self] Coinflip: landed on edge. Lost {self.gamble_amount / 2} SCP.", "RED")
        self.coinflip_pending = False

    def _handle_bot_embed(self, embed: dict):
        title       = embed.get("title", "")
        description = embed.get("description", "")

        if title == "Success" and "You have bought" in description:
            m = re.search(r"You bought (\d+) Gold Bars?", description)
            if m:
                amount = int(m.group(1))
                session.sniped_gold += amount
                self.log(f"[self] Sniped {amount} gold bars.", "YELLOW")
            self.checking_gold = False
            self.queue("CHECK_SNIPE", self.jitter(60))

        elif title == "Error":
            if "You do not" in description and "SCP" in description:
                if self.snipe_amount > 1:
                    new_amt = self.snipe_amount - 1
                    self.log(f"[self] Not enough SCP. Retrying with {new_amt} bars.", "YELLOW")
                    self.queue("SNIPE", self.jitter(1), {"gold_amount": new_amt})
                else:
                    self.log("[self] Not enough SCP to snipe even 1 bar.", "RED")
                    self.checking_gold = False
                    self.queue("CHECK_SNIPE", self.jitter(60))

            elif "The bank does not have enough gold bars" in description:
                self.log("[self] Bank ran out of gold bars.", "RED")
                self.checking_gold = False
                self.queue("CHECK_SNIPE", self.jitter(60))

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def loop(self):
        now = time.time()
        self._check_holger_timeout(now)
        self.check_trivia_retry_timeout(now)

        due = next(
            ((evt, fire_at, kw) for evt, fire_at, kw in self.queue_logs if fire_at <= now),
            None
        )
        if due:
            self._dispatch(due, now)

    def _check_holger_timeout(self, now: float):
        if self.waiting_for_holger or self.pending_button or self.checking_gold:
            return
        for event, fire_at, _ in self.queue_logs:
            if event == "NEXT_GLORY" and (now - fire_at) > 25:
                self.waiting_for_holger = False
                self.log("[self] Holger didn't respond. Resetting.", "RED")
                break

    def _dispatch(self, due: tuple, now: float):
        event, _, kwargs = due
        time_since_send = now - self.last_send_time

        if event == "NEXT_GLORY":
            self._dispatch_next_glory(due, time_since_send)
        elif event == "CLICK_BUTTON":
            self.click(**kwargs)
            session.buttons += 1
            self.queue_logs.remove(due)
            self.pending_button = False
            self.shift_event("NEXT_GLORY", -15)
            self.log(f"[self] Clicked button: {kwargs['custom_id']}", "GREEN")
        elif event == "TRIVIA_REPLY":
            self._dispatch_trivia_reply(due, time_since_send, kwargs)
        elif event == "CHECK_SNIPE":
            self._dispatch_check_snipe(due)
        elif event == "SNIPE":
            self._dispatch_snipe(due, kwargs)
        elif event == "COINFLIP":
            self._dispatch_coinflip(due, kwargs)
        elif event == "STAFF_CLEAR":
            self.queue_logs.remove(due)
            self.staff_present = False
            self.log("[self] Staff gone. Resuming.", "RED")

    def _dispatch_next_glory(self, due: tuple, time_since_send: float):
        if self.waiting_for_holger or self.pending_button or self.checking_gold:
            return

        if settings.paused:
            self.shift_event("NEXT_GLORY", 5.0)
            self.log("[self] Grind paused (/pause active).", "RED")
            return

        if self.staff_present and settings.auto_stop:
            self.shift_event("NEXT_GLORY", 5.0)
            self.log("[self] Grind paused (staff in chat).", "RED")
            return

        if self.trivia_state:
            self.shift_event("NEXT_GLORY", 5.0)
            self.log("[self] Grind paused (trivia active).", "MAGENTA")
            return

        if time_since_send < SLOWMODE_DELAY:
            delay = SLOWMODE_DELAY - time_since_send
            self.shift_event("NEXT_GLORY", delay)
            self.log(f"[self] Grind delayed by {delay:.1f}s (slowmode).", "RED")
            return

        self.waiting_for_holger = True
        self.subscribe_to_channel(GUILD_ID, GRIND_ID)
        self.send_message(GRIND_ID, GRIND_MESSAGE)
        self.last_send_time = time.time()
        self.queue_logs.remove(due)
        self.log("[self] Sent grind message.")

    def _dispatch_trivia_reply(self, due: tuple, time_since_send: float, kwargs: dict):
        if not self.trivia_state:
            self.queue_logs.remove(due)
            return

        if settings.paused:
            self.shift_event("TRIVIA_REPLY", 5.0)
            self.log("[self] Trivia reply paused (/pause active).", "RED")
            return

        if self.staff_present and settings.auto_stop:
            self.shift_event("TRIVIA_REPLY", 5.0)
            self.log("[self] Trivia reply paused (staff in chat).", "RED")
            return

        if time_since_send < SLOWMODE_DELAY:
            delay = SLOWMODE_DELAY - time_since_send
            self.shift_event("TRIVIA_REPLY", delay)
            self.log(f"[self] Trivia reply delayed by {delay:.1f}s (slowmode).")
            return

        answer = self.resolve_trivia_answer()
        if answer:
            self.send_message(kwargs["channel_id"], answer, kwargs["message_id"])
            self.last_send_time = time.time()
            self.trivia_state["last_sent_answer"] = answer
            self.trivia_state["last_sent_at"]      = time.time()
            self.log(f"[self] Sent trivia answer: {answer}", "MAGENTA")
        else:
            self.log("[self] No answer available for trivia.", "RED")

        self.queue_logs.remove(due)

    def _dispatch_check_snipe(self, due: tuple):
        self.checking_gold = True
        self.queue_logs.remove(due)
        self.subscribe_to_channel(GUILD_ID, BOT_C_ID)
        self.command(
            application_id=HOLGER_ID,
            channel_id=BOT_C_ID,
            command_id=SHOP_COMMAND_ID,
            command_name="shop",
            version=SHOP_COMMAND_VERSION,
            guild_id=GUILD_ID,
            options=[{
                "type": 1,
                "name": "check",
                "options": [
                    {"type": 3, "name": "value",  "value": "gold bars"},
                    {"type": 6, "name": "member", "value": HOLGER_ID},
                ],
            }],
        )

    def _dispatch_snipe(self, due: tuple, kwargs: dict):
        self.queue_logs.remove(due)
        self.shift_event("COINFLIP", 2)
        amount = kwargs.get("gold_amount", 0)

        if amount <= 0:
            self.checking_gold = False
            self.queue("CHECK_SNIPE", self.jitter(60))
            return

        self.snipe_amount = amount
        self.log(f"[self] Attempting to snipe {amount} gold bars.", "YELLOW")
        self.subscribe_to_channel(GUILD_ID, BOT_C_ID)
        self.command(
            application_id=HOLGER_ID,
            channel_id=BOT_C_ID,
            command_id=SHOP_COMMAND_ID,
            command_name="shop",
            version=SHOP_COMMAND_VERSION,
            guild_id=GUILD_ID,
            options=[{
                "type": 1,
                "name": "buy",
                "options": [
                    {"type": 3, "name": "item",   "value": "\ud83d\udcb0Gold bar"},
                    {"type": 4, "name": "amount", "value": amount},
                ],
            }],
        )

    def _dispatch_coinflip(self, due: tuple, kwargs: dict):
        self.queue_logs.remove(due)
        amount = kwargs.get("scp", 0)
        self.gamble_amount = amount
        self.coinflip_pending = True
        self.log(f"[self] Coinflip: betting {amount} SCP on heads.", "BLUE")
        self.subscribe_to_channel(GUILD_ID, BOT_C_ID)
        self.command(
            application_id=HOLGER_ID,
            channel_id=BOT_C_ID,
            command_id=SCP_COMMAND_ID,
            command_name="scp",
            version=SCP_COMMAND_VERSION,
            guild_id=GUILD_ID,
            options=[{
                "type": 1,
                "name": "coinflip",
                "options": [
                    {"type": 4, "name": "amount", "value": amount},
                    {"type": 3, "name": "side",   "value": "heads"},
                ],
            }],
        )


# ---------------------------------------------------------------------------
# Discord Bot — runs in a background thread, logs into client.event_logs
# ---------------------------------------------------------------------------

if HAS_DISCORD:
    class DiscordGrindBot(commands.Bot):
        def __init__(self, grind_client: Client, bot_instance, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.grind_client = grind_client
            self.bot_instance = bot_instance

        async def setup_hook(self):
            holger_trivia_cmd = app_commands.ContextMenu(
                name="Holger Trivia",
                callback=self.bot_instance.holger_trivia_callback,
            )
            search_ans_cmd = app_commands.ContextMenu(
                name="Search Answer",
                callback=self.bot_instance.search_ans_callback,
            )
            self.tree.add_command(holger_trivia_cmd)
            self.tree.add_command(search_ans_cmd)

            await self.tree.sync()

            self.grind_client.log("Bot ready. Global user commands synced.", "GREEN")

    class Bot:
        def __init__(self, grind_client: Client):
            self.grind_client = grind_client

            intents = discord.Intents.default()
            intents.message_content = True

            self.client = DiscordGrindBot(
                grind_client=self.grind_client,
                bot_instance=self,
                command_prefix="!",
                intents=intents
            )

            @self.client.tree.command(name="session", description="Show stats for the current grind session.")
            async def cmd_session(interaction: discord.Interaction):
                s  = session
                rt = max(1e-9, time.time() - self.grind_client._start_time) if hasattr(self.grind_client, "_start_time") else 1.0
                h  = 3600 / rt

                credit_pct = (s.credits / s.count * 100)          if s.count  else 0.0
                trivia_pct = (s.trivia_answered / s.trivia * 100) if s.trivia else 0.0
                bar_pct    = (s.gold_bars / s.count * 100)        if s.count  else 0.0
                raw_scp    = s.scp + s.trivia_scp

                hours   = int(rt // 3600)
                minutes = int((rt % 3600) // 60)
                secs    = int(rt % 60)
                uptime  = f"{hours}h {minutes}m {secs}s"

                embed = discord.Embed(title="Session Stats", color=0x5865F2)
                embed.add_field(name="Uptime",       value=uptime, inline=False)
                embed.add_field(name="Messages",     value=f"`{s.count}` messages  |  `{credit_pct:.1f}%` credit chance", inline=False)
                embed.add_field(name="Message SCP",  value=f"`{s.scp}` total  |  `{s.scp * h:.0f}` /h", inline=True)
                embed.add_field(name="Trivia SCP",   value=f"`{s.trivia_scp}` total  |  `{s.trivia_scp * h:.0f}` /h\n`{s.trivia_answered}/{s.trivia}` answered (`{trivia_pct:.1f}%`)", inline=True)
                embed.add_field(name="Total SCP",    value=f"`{raw_scp}` total  |  `{raw_scp * h:.0f}` /h", inline=False)
                embed.add_field(name="Gold Bars",    value=f"`{s.gold_bars}` dropped (`{bar_pct:.1f}%`)  |  `{s.sniped_gold}` sniped", inline=False)
                embed.add_field(name="Coinflips",    value=f"`{s.coinflips}` flips  |  `{s.coinflips_won}` won  |  `{s.coinflips_scp:+}` net SCP", inline=False)
                self.grind_client.log("[bot] /session requested")
                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="lifetime", description="Show all-time cumulative grind stats.")
            async def cmd_lifetime(interaction: discord.Interaction):
                class _T:
                    pass
                t = _T()
                for k in Stats.KEYS:
                    setattr(t, k, getattr(lifetime, k) + getattr(session, k))

                credit_pct = (t.credits / t.count * 100)           if t.count     else 0.0
                trivia_pct = (t.trivia_answered / t.trivia * 100)  if t.trivia    else 0.0
                bar_pct    = (t.gold_bars / t.count * 100)         if t.count     else 0.0
                cf_win_pct = (t.coinflips_won / t.coinflips * 100) if t.coinflips else 0.0
                raw_scp    = t.scp + t.trivia_scp

                embed = discord.Embed(title="Lifetime Stats", color=0xF1C40F)
                embed.add_field(name="Messages",   value=f"`{t.count}` total  |  `{credit_pct:.1f}%` credit chance", inline=False)
                embed.add_field(name="Message SCP",value=f"`{t.scp}`", inline=True)
                embed.add_field(name="Trivia SCP", value=f"`{t.trivia_scp}`  |  `{trivia_pct:.1f}%` answered", inline=True)
                embed.add_field(name="Total SCP",  value=f"`{raw_scp}`", inline=False)
                embed.add_field(name="Gold Bars",  value=f"`{t.gold_bars}` dropped (`{bar_pct:.1f}%`)  |  `{t.sniped_gold}` sniped", inline=False)
                embed.add_field(name="Coinflips",  value=f"`{t.coinflips}` flips  |  `{t.coinflips_won}` won (`{cf_win_pct:.1f}%`)  |  `{t.coinflips_scp:+}` net SCP", inline=False)
                self.grind_client.log("[bot] /lifetime requested")
                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="settings", description="View or toggle bot settings.")
            @app_commands.describe(setting="Which setting to toggle (omit to just view current settings)")
            @app_commands.choices(setting=[
                app_commands.Choice(name="Grind SCP",    value="grind_scp"),
                app_commands.Choice(name="Grind Trivia", value="grind_trivia"),
                app_commands.Choice(name="Snipe Gold",   value="snipe"),
                app_commands.Choice(name="Coinflip",     value="gamble"),
                app_commands.Choice(name="Auto-Stop",    value="auto_stop"),
            ])
            async def cmd_settings(interaction: discord.Interaction, setting: str | None = None):
                LABELS = {
                    "grind_scp":    "Grind SCP",
                    "grind_trivia": "Grind Trivia",
                    "snipe":        "Snipe Gold",
                    "gamble":       "Coinflip",
                    "auto_stop":    "Auto-Stop",
                }

                if setting is not None:
                    attr    = setting
                    new_val = not getattr(settings, attr)
                    setattr(settings, attr, new_val)
                    save_settings()
                    state = "ON" if new_val else "OFF"
                    self.grind_client.log(f"[bot] {LABELS[attr]} toggled -> {state}")

                embed = discord.Embed(title="Bot Settings", color=0x2ECC71)
                if setting is not None:
                    state = "ON" if getattr(settings, setting) else "OFF"
                    embed.description = f"{LABELS[setting]} toggled -> {state}"

                for attr, label in LABELS.items():
                    embed.add_field(name=label, value="ON" if getattr(settings, attr) else "OFF", inline=True)
                embed.add_field(name="Paused", value="YES" if settings.paused else "NO", inline=True)

                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="status", description="Show what the bot is currently doing.")
            async def cmd_status(interaction: discord.Interaction):
                gc = self.grind_client

                if settings.paused:
                    state = "Paused (via /pause)"
                elif gc.staff_present and settings.auto_stop:
                    state = "Paused (staff in grind channel)"
                elif gc.trivia_state:
                    state = "Answering trivia"
                elif gc.waiting_for_holger:
                    state = "Waiting on Holger's response"
                elif gc.pending_button:
                    state = "Waiting to click a button"
                elif gc.checking_gold:
                    state = "Checking the shop for gold bars"
                else:
                    state = "Idle / between actions"

                embed = discord.Embed(title="Bot Status", color=0x3498DB)
                embed.add_field(name="Current state", value=state, inline=False)

                if gc.trivia_state:
                    q = gc.trivia_state.get("question", "")
                    remaining = gc.trivia_state.get("candidates", [])
                    embed.add_field(
                        name="Trivia",
                        value=f"{q[:200]}\nCandidates left: `{len(remaining)}`",
                        inline=False,
                    )

                queued = list(gc.queue_logs)[-6:]
                if queued:
                    now = time.time()
                    lines = "\n".join(
                        f"`{evt}` in {max(0.0, fire_at - now):.1f}s" for evt, fire_at, _ in queued
                    )
                    embed.add_field(name="Upcoming queue", value=lines, inline=False)

                embed.add_field(
                    name="Toggles",
                    value=(
                        f"Grind SCP: {'ON' if settings.grind_scp else 'OFF'}  |  "
                        f"Trivia: {'ON' if settings.grind_trivia else 'OFF'}  |  "
                        f"Snipe: {'ON' if settings.snipe else 'OFF'}  |  "
                        f"Coinflip: {'ON' if settings.gamble else 'OFF'}  |  "
                        f"Auto-Stop: {'ON' if settings.auto_stop else 'OFF'}"
                    ),
                    inline=False,
                )
                self.grind_client.log("[bot] /status requested")
                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="reset_session", description="Reset this run's session stats back to zero.")
            async def cmd_reset_session(interaction: discord.Interaction):
                for k in Stats.KEYS:
                    setattr(session, k, 0)
                self.grind_client._start_time = time.time()
                self.grind_client.log("[bot] /reset_session: session stats cleared.", "GREEN")
                await interaction.response.send_message("Session stats have been reset.", ephemeral=False)

            @self.client.tree.command(name="trivia_bank", description="Show how many trivia Q&A pairs are stored.")
            async def cmd_trivia_bank(interaction: discord.Interaction):
                embed = discord.Embed(title="Trivia Bank", color=0x9B59B6)
                embed.add_field(name="Stored questions", value=f"`{len(TRIVIA_BANK)}`", inline=False)
                self.grind_client.log("[bot] /trivia_bank requested")
                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="pause", description="Pause grinding and trivia (snipe keeps running).")
            async def cmd_pause(interaction: discord.Interaction):
                if settings.paused:
                    await interaction.response.send_message("Already paused.", ephemeral=False)
                    return

                settings._pre_pause_grind_scp    = settings.grind_scp
                settings._pre_pause_grind_trivia = settings.grind_trivia
                settings.grind_scp    = False
                settings.grind_trivia = False
                settings.paused       = True

                self.grind_client.log("[bot] /pause: grinding and trivia paused.", "GREEN")
                await interaction.response.send_message("Paused grinding and trivia. Use /unpause to resume.", ephemeral=False)

            @self.client.tree.command(name="unpause", description="Resume grinding and trivia after a /pause.")
            async def cmd_unpause(interaction: discord.Interaction):
                if not settings.paused:
                    await interaction.response.send_message("Not currently paused.", ephemeral=False)
                    return

                settings.grind_scp    = settings._pre_pause_grind_scp
                settings.grind_trivia = settings._pre_pause_grind_trivia
                settings.paused       = False

                self.grind_client.log("[bot] /unpause: grinding and trivia resumed.", "GREEN")
                await interaction.response.send_message("Resumed grinding and trivia.", ephemeral=False)

            @self.client.tree.command(name="logs", description="Show previous logs, most recent first.")
            @app_commands.describe(
                page="Which page to view (1 = most recent)",
                amount="How many logs per page",
            )
            async def cmd_logs(interaction: discord.Interaction, page: int = 1, amount: int = 10):
                page   = max(1, page)
                amount = max(1, min(amount, 50))

                entries, total = read_log_lines(page, amount)
                max_page = max(1, (total + amount - 1) // amount)

                if not entries:
                    await interaction.response.send_message(
                        f"No logs on page {page} (there are `{total}` total, `{max_page}` pages).",
                        ephemeral=False,
                    )
                    return

                lines = []
                for entry in entries:
                    ts  = entry.get("ts", 0)
                    msg = entry.get("message", "")
                    stamp = time.strftime("%H:%M:%S", time.localtime(ts))
                    lines.append(f"`[{stamp}]` {msg}")

                embed = discord.Embed(
                    title=f"Logs — page {page}/{max_page}",
                    description="\n".join(lines)[:4000],
                    color=0x95A5A6,
                )
                embed.set_footer(text=f"{total} total logs  |  {amount} per page")
                self.grind_client.log(f"[bot] /logs requested (page {page}, amount {amount})")
                await interaction.response.send_message(embed=embed, ephemeral=False)

            @self.client.tree.command(name="clearlogs", description="Clear the stored log file.")
            async def cmd_clearlogs(interaction: discord.Interaction):
                clear_log_file()
                self.grind_client.log("[bot] /clearlogs: log file cleared.", "GREEN")
                await interaction.response.send_message("Log file cleared.", ephemeral=False)

            self._attach_log_handler()

        def _attach_log_handler(self):
            grind = self.grind_client
            class CursesHandler(logging.Handler):
                def emit(self, record):
                    msg   = record.getMessage()
                    color = "RED" if record.levelno >= logging.WARNING else "WHITE"
                    grind.log(f"[discord] {msg}", color)

            handler = CursesHandler()
            discord_logger = logging.getLogger("discord")
            discord_logger.addHandler(handler)
            discord_logger.setLevel(logging.WARNING)
            discord_logger.propagate = False

        async def holger_trivia_callback(self, interaction: discord.Interaction, message: discord.Message):
            if not message.embeds:
                await interaction.response.send_message("No embed on that message.", ephemeral=True)
                return

            question = normalize(message.embeds[0].description or "")
            entry    = find_trivia(question)

            if entry:
                ans = entry["correct_answer"]
                self.grind_client.log(f"[bot] Trivia lookup: {ans}", "MAGENTA")
                await interaction.response.send_message(f"`{ans}`", ephemeral=True)
            else:
                self.grind_client.log("[bot] Trivia lookup: not found", "RED")
                await interaction.response.send_message("No answer found in the trivia bank.", ephemeral=True)

        async def search_ans_callback(self, interaction: discord.Interaction, message: discord.Message):
            if not message.embeds:
                await interaction.response.send_message("No embed on that message.", ephemeral=True)
                return

            question = normalize(message.embeds[0].description or "")
            self.grind_client.log(f"[bot] AI lookup: {question[:50]}...", "MAGENTA")

            await interaction.response.defer(ephemeral=True)
            try:
                async with aiohttp.ClientSession() as sess:
                    headers = {
                        "Authorization": "Bearer sk_a8ZhE6UsGtjg0hT8xWHw4TOtHgMIMr7P",
                        "Content-Type":  "application/json",
                    }
                    async with sess.get(
                        "https://gen.pollinations.ai/v1/chat/completions",
                        headers=headers,
                        json={
                            "model": "perplexity-fast",
                            "messages": [
                                {
                                    "role":    "system",
                                    "content": "Say ONLY the answer to the trivia question, nothing else.",
                                },
                                {"role": "user", "content": question},
                            ],
                        },
                    ) as resp:
                        data   = await resp.json()
                        answer = (
                            data.get("choices", [{}])[0]
                                .get("message", {})
                                .get("content", "No answer returned.")
                        )

                self.grind_client.log(f"[bot] AI answer: {answer[:50]}", "MAGENTA")
                await interaction.followup.send(f"`{answer}`", ephemeral=True)

            except Exception as e:
                self.grind_client.log(f"[bot] AI error: {e}", "RED")
                await interaction.followup.send(f"Error: {e}", ephemeral=True)

        def start(self):
            loop = asyncio.new_event_loop()
            def _run():
                asyncio.set_event_loop(loop)
                try:
                    self.client.run("NzU3NjU3MzY3NzkzMTA3MDk1.GnPtXu.xFTSq4SNmDBJYN4BobR4LIi9TmPjBsM9AmoxQ8", reconnect=True)
                except Exception as e:
                    self.grind_client.log(f"Bot failed to start: {e}", "RED")

            t = threading.Thread(target=_run, daemon=True, name="discord-bot")
            t.start()
            self.grind_client.log("Bot thread started.", "GREEN")

# ---------------------------------------------------------------------------
# Curses UI
# ---------------------------------------------------------------------------

class CursesUI:
    SETTINGS_OPTIONS = [
        ("grind_scp",    "Grind SCP"),
        ("grind_trivia", "Grind Trivia"),
        ("snipe",        "Snipe Gold"),
        ("gamble",       "Coinflip"),
        ("auto_stop",    "Auto-Stop"),
    ]

    COLOR_MAP = {
        "RED":     1,
        "GREEN":   2,
        "YELLOW":  3,
        "BLUE":    4,
        "MAGENTA": 5,
    }

    def __init__(self, client: Client):
        self.client       = client
        self.start_time   = time.time()
        self.page         = 0
        self.max_pages    = 5
        self.settings_idx = 0
        self.recent_events: deque[tuple] = deque(maxlen=8)

        self.win = curses.initscr()
        self.win.nodelay(True)
        self.win.keypad(True)
        curses.noecho()
        curses.cbreak()
        curses.curs_set(0)
        curses.start_color()

        curses.init_pair(1, curses.COLOR_RED,     curses.COLOR_BLACK)
        curses.init_pair(2, curses.COLOR_GREEN,   curses.COLOR_BLACK)
        curses.init_pair(3, curses.COLOR_YELLOW,  curses.COLOR_BLACK)
        curses.init_pair(4, curses.COLOR_BLUE,    curses.COLOR_BLACK)
        curses.init_pair(5, curses.COLOR_MAGENTA, curses.COLOR_BLACK)

    def _color(self, name: str) -> int:
        pair = self.COLOR_MAP.get(name)
        return curses.color_pair(pair) if pair else curses.A_NORMAL

    def _handle_input(self, key: int):
        if key in (ord("<"), ord(","), curses.KEY_LEFT):
            self.page = (self.page - 1) % self.max_pages
        elif key in (ord(">"), ord("."), curses.KEY_RIGHT):
            self.page = (self.page + 1) % self.max_pages
        elif key == ord("q"):
            curses.nocbreak()
            curses.echo()
            curses.endwin()
            exit()
        elif self.page == 4:
            if key == curses.KEY_UP:
                self.settings_idx = (self.settings_idx - 1) % len(self.SETTINGS_OPTIONS)
            elif key == curses.KEY_DOWN:
                self.settings_idx = (self.settings_idx + 1) % len(self.SETTINGS_OPTIONS)
            elif key in (curses.KEY_ENTER, 10, 13):
                attr = self.SETTINGS_OPTIONS[self.settings_idx][0]
                setattr(settings, attr, not getattr(settings, attr))
                save_settings()

    def draw(self):
        self.win.erase()
        self._handle_input(self.win.getch())

        nav = "< / > to navigate, q to quit"

        pages = {
            0: self._page_logs,
            1: self._page_session,
            2: self._page_lifetime,
            3: self._page_gambling,
            4: self._page_settings,
        }
        pages[self.page](nav)
        self.win.refresh()

    def _page_logs(self, nav: str):
        self.win.addstr(0, 0, f"Logs  -  {nav}", curses.A_BOLD)

        self.win.addstr(2, 0,  "Queue",  curses.A_REVERSE)
        for i, (event, fire_at, _) in enumerate(list(self.client.queue_logs)[-8:]):
            remaining = max(0.0, fire_at - time.time())
            self.win.addstr(3 + i, 0, f"{event}: {remaining:.1f}s")

        self.win.addstr(2, 30, "Events", curses.A_REVERSE)
        while self.client.event_logs:
            self.recent_events.append(self.client.event_logs.popleft())
        for i, (msg, color) in enumerate(self.recent_events):
            self.win.addstr(3 + i, 30, msg, self._color(color))

    def _page_session(self, nav: str):
        s   = session
        rt  = max(1e-9, time.time() - self.start_time)
        h   = 3600 / rt

        credit_pct = (s.credits / s.count * 100)          if s.count  else 0.0
        trivia_pct = (s.trivia_answered / s.trivia * 100) if s.trivia else 0.0
        bar_pct    = (s.gold_bars / s.count * 100)        if s.count  else 0.0
        btn_rate   = rt / s.buttons                        if s.buttons else 0.0
        btn_pct    = (s.buttons / s.count * 100)          if s.count  else 0.0
        snipe_rate = rt / s.sniped_gold                    if s.sniped_gold else 0.0
        raw_scp    = s.scp + s.trivia_scp

        self.win.addstr(0, 0, f"Session Stats  -  {nav}", curses.A_BOLD)
        self.win.addstr(2, 0, f"Messages: {s.count}  |  Trivia: {s.trivia}")
        self.win.addstr(3, 0, f"Message SCP: {s.scp}  |  Credit chance: {credit_pct:.1f}%  |  {s.scp * h:.1f} SCP/h")
        self.win.addstr(4, 0, f"Trivia SCP:  {s.trivia_scp}  |  Answered: {trivia_pct:.1f}%  |  {s.trivia_scp * h:.1f} SCP/h")
        self.win.addstr(5, 0, f"Total SCP:   {raw_scp}  |  {raw_scp * h:.1f} SCP/h")
        self.win.addstr(6, 0, f"Gold bars:   {s.gold_bars}  |  Drop rate: {bar_pct:.1f}%")
        self.win.addstr(7, 0, "(Gold bars from drops only. Sniped bars tracked separately)", curses.A_DIM)
        self.win.addstr(9, 0,  f"Buttons: {s.buttons}  |  Every ~{btn_rate:.1f}s  |  {btn_pct:.1f}% per message")
        self.win.addstr(10, 0, f"Sniped: {s.sniped_gold} bars  |  Restock every ~{snipe_rate:.1f}s")

    def _page_lifetime(self, nav: str):
        class _T:
            pass
        t = _T()
        for k in Stats.KEYS:
            setattr(t, k, getattr(lifetime, k) + getattr(session, k))

        credit_pct = (t.credits / t.count * 100)          if t.count  else 0.0
        trivia_pct = (t.trivia_answered / t.trivia * 100) if t.trivia else 0.0
        bar_pct    = (t.gold_bars / t.count * 100)        if t.count  else 0.0
        btn_pct    = (t.buttons / t.count * 100)          if t.count  else 0.0
        raw_scp    = t.scp + t.trivia_scp

        self.win.addstr(0, 0, f"Lifetime Stats  -  {nav}", curses.A_BOLD)
        self.win.addstr(2, 0, f"Messages: {t.count}  |  Trivia: {t.trivia}")
        self.win.addstr(3, 0, f"Message SCP: {t.scp}  |  Credit chance: {credit_pct:.1f}%")
        self.win.addstr(4, 0, f"Trivia SCP:  {t.trivia_scp}  |  Answered: {trivia_pct:.1f}%")
        self.win.addstr(5, 0, f"Total SCP:   {raw_scp}")
        self.win.addstr(6, 0, f"Gold bars:   {t.gold_bars}  |  Drop rate: {bar_pct:.1f}%")
        self.win.addstr(7, 0, "(Gold bars from drops only. Sniped bars tracked separately)", curses.A_DIM)
        self.win.addstr(9, 0, f"Buttons: {t.buttons}  |  {btn_pct:.1f}% per message")
        self.win.addstr(10, 0, f"Sniped: {t.sniped_gold} bars")

    def _page_gambling(self, nav: str):
        s  = session
        rt = max(1e-9, time.time() - self.start_time)
        tc = lifetime.coinflips + s.coinflips
        tw = lifetime.coinflips_won + s.coinflips_won
        tl = tc - tw
        tn = lifetime.coinflips_scp + s.coinflips_scp

        s_losses  = s.coinflips - s.coinflips_won
        s_win_pct = (s.coinflips_won / s.coinflips * 100) if s.coinflips else 0.0
        t_win_pct = (tw / tc * 100) if tc else 0.0

        self.win.addstr(0, 0, f"Gambling  -  {nav}", curses.A_BOLD)
        self.win.addstr(2,  0, f"Session flips: {s.coinflips}")
        self.win.addstr(3,  0, f"Wins: {s.coinflips_won}  |  Losses: {s_losses}")
        self.win.addstr(4,  0, f"Win rate: {s_win_pct:.1f}%")
        self.win.addstr(5,  0, f"Net SCP: {s.coinflips_scp}")
        self.win.addstr(6,  0, f"SCP/h: {s.coinflips_scp * 3600 / rt:.1f}")
        self.win.addstr(8,  0, f"Lifetime flips: {tc}")
        self.win.addstr(9,  0, f"Wins: {tw}  |  Losses: {tl}")
        self.win.addstr(10, 0, f"Win rate: {t_win_pct:.1f}%")
        self.win.addstr(11, 0, f"Net SCP: {tn}")

    def _page_settings(self, nav: str):
        self.win.addstr(0, 0, f"Settings  -  {nav}", curses.A_BOLD)
        for i, (attr, label) in enumerate(self.SETTINGS_OPTIONS):
            value = getattr(settings, attr)
            style = curses.A_REVERSE if i == self.settings_idx else curses.A_NORMAL
            self.win.addstr(2 + i, 0, f"{label}: {'ON' if value else 'OFF'}", style)


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="SCP grind bot")
    parser.add_argument("--token",     type=str, help="Discord user token")
    parser.add_argument("--bot-token", type=str, help="Discord bot token")
    parser.add_argument("--no-ui",     action="store_true", default=False, help="Run without curses UI")
    parser.add_argument("--no-bot",    action="store_true", default=False, help="Run without Discord bot")
    args = parser.parse_args()

    token = args.token
    if not token:
        load_dotenv()
        token = os.getenv("TOKEN")
    if not token:
        raise ValueError("No user token provided. Set TOKEN in .env or pass --token.")

    load_all()
    atexit.register(save_all)

    client = Client(token)
    client.start(run_forever=False)

    ui = None
    if not args.no_ui and HAS_CURSES:
        logging.getLogger("DiscordWS").setLevel(logging.CRITICAL)
        logging.getLogger("discord").setLevel(logging.CRITICAL)
        ui = CursesUI(client)

    bot = None
    if not args.no_bot and HAS_DISCORD:
        bot = Bot(client)
        bot.start()

    while True:
        client.loop()
        if ui:
            ui.draw()
        time.sleep(0.05)